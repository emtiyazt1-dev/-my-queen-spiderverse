MY QUEEN — FINAL CODE PACKAGE

Ei package-e tomar uploaded App-fixed-final.tsx-er existing pages/design rekhe ei upgrade gulo add kora hoyeche:
- Supabase email/password login (dui jon-er alada account)
- Password reset email
- Private realtime chat + photo/audio attachment
- Visual music player: playlist, play/pause, previous/next, shuffle/repeat, seek, volume
- Supabase RLS SQL and private chat attachment policies

FILES:
1) src/App.tsx       -> GitHub-er src/App.tsx replace koro
2) src/lib.ts        -> GitHub-er src/lib.ts replace koro
3) src/ChatPage.tsx  -> notun file add koro
4) src/MusicPlayer.tsx -> notun file add koro
5) src/mq-upgrades.css -> notun file add koro
6) supabase-setup.sql -> Supabase SQL Editor-e run koro

IMPORTANT:
- Tomar original App.css, main.tsx, package.json and Vite config unchanged rakhbe.
- Project-e @supabase/supabase-js, framer-motion, lucide-react install thakte hobe (existing App already egulo use kore).
- Vercel Environment Variables:
  VITE_SUPABASE_URL = Supabase Project URL
  VITE_SUPABASE_ANON_KEY = Supabase anon/public key
  VITE_CHAT_CONVERSATION_ID = created conversation UUID
- Kono service_role key frontend/Vercel public env-e dio na.

SETUP ORDER:
1) Supabase > Authentication > Users e duita user create koro (tomar email + Queen-er email). Dui jon-er jonno alada password set koro.
2) SQL Editor-e supabase-setup.sql run koro.
3) Authentication > Users theke duijoner UUID copy koro.
4) SQL Editor-e niche-r query-te UUID boshiye run koro:

insert into public.queen_conversations (title) values ('Our private chat') returning id;

Query-r returned id holo CONVERSATION_ID. Tarpor:

insert into public.queen_conversation_members (conversation_id, user_id) values
('CONVERSATION_ID_HERE', 'YOUR_USER_UUID_HERE'),
('CONVERSATION_ID_HERE', 'QUEEN_USER_UUID_HERE');

5) Vercel > Project > Settings > Environment Variables e 3ta VITE variable add koro. Redeploy koro.
6) Supabase > Authentication > URL Configuration e Site URL tomar Vercel domain dao (e.g. https://my-queen-spiderverse.vercel.app) ebong Redirect URLs-e oi domain + https://my-queen-spiderverse.vercel.app/** add koro.
7) GitHub-e source files replace/add kore commit koro. Vercel auto-deploy korbe.
8) Website-e tumi tomar email/password diye login korbe. Queen tar phone-e tar own email/password diye login korbe.

IMPORTANT DATA NOTES:
- Existing app_state data is per-user because RLS scopes rows to auth.uid(). Each account has its own personal wishes/gallery/notes unless you deliberately build a shared-content model.
- Chat is shared only with the two UUIDs added to the conversation.
- Music playlist is stored in IndexedDB on the current browser/device; it does not sync between phones. Upload songs separately on each device.
- Supabase private chat/storage is access-controlled but NOT end-to-end encrypted.
- Photo/music browser local data from old local-password sessions may remain in that browser. Cloud data belongs to the signed-in account.
