import { useCallback, useEffect, useRef, useState, type FormEvent } from 'react';
import { Paperclip, Send, RefreshCw, Image as ImageIcon, Music2, CheckCheck } from 'lucide-react';
import { supabase, getChatMessages, sendChatMessage, getChatAttachmentUrl, markChatRead, type ChatMessage } from './lib';

const CONVERSATION_ID = import.meta.env.VITE_CHAT_CONVERSATION_ID as string | undefined;
export default function ChatPage() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [body, setBody] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [urls, setUrls] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [myId, setMyId] = useState('');
  const bottom = useRef<HTMLDivElement>(null);

  const refresh = useCallback(async () => {
    if (!supabase) { setError('Supabase is not configured.'); return; }
    if (!CONVERSATION_ID) { setError('Add VITE_CHAT_CONVERSATION_ID in Vercel Environment Variables.'); return; }
    try {
      const [{ data: { user } }, rows] = await Promise.all([supabase.auth.getUser(), getChatMessages(CONVERSATION_ID)]);
      if (user) setMyId(user.id);
      setMessages(rows);
      await markChatRead(rows.filter(m => m.sender_id !== user?.id && !m.read_at).map(m => m.id));
      const missing = rows.filter(m => m.attachment_path && !urls[m.id]);
      if (missing.length) {
        const entries = await Promise.all(missing.map(async m => [m.id, await getChatAttachmentUrl(m.attachment_path!)] as const));
        setUrls(old => ({ ...old, ...Object.fromEntries(entries) }));
      }
      setError('');
    } catch (e) { setError(e instanceof Error ? e.message : 'Could not load messages.'); }
  }, [urls]);

  useEffect(() => { void refresh(); }, [refresh]);
  useEffect(() => {
    if (!supabase || !CONVERSATION_ID) return;
    const channel = supabase.channel(`queen-chat-${CONVERSATION_ID}`).on('postgres_changes', { event: '*', schema: 'public', table: 'queen_messages', filter: `conversation_id=eq.${CONVERSATION_ID}` }, () => void refresh()).subscribe();
    return () => { void supabase.removeChannel(channel); };
  }, [refresh]);
  useEffect(() => { bottom.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  async function submit(e: FormEvent) {
    e.preventDefault(); if ((!body.trim() && !file) || busy || !CONVERSATION_ID) return;
    setBusy(true); setError('');
    try { await sendChatMessage(CONVERSATION_ID, body, file || undefined); setBody(''); setFile(null); await refresh(); }
    catch (e) { setError(e instanceof Error ? e.message : 'Message could not be sent.'); }
    finally { setBusy(false); }
  }

  return <section className="mq-chat panel">
    <header className="mq-chat-head"><div><span className="eyebrow">JUST YOU TWO · PRIVATE SPACE</span><h2>Our private messages ❤️</h2><p>Send a little love, wherever you are.</p></div><button type="button" className="icon-btn" onClick={() => void refresh()} aria-label="Refresh messages"><RefreshCw size={17}/></button></header>
    {error && <p role="alert" className="mq-chat-error">{error}</p>}
    <div className="mq-chat-list" aria-live="polite">
      {messages.map(message => {
        const mine = message.sender_id === myId;
        const mediaUrl = urls[message.id];
        return <article key={message.id} className={`mq-chat-message ${mine ? 'mine' : 'theirs'}`}>
          {message.body && <p>{message.body}</p>}
          {message.attachment_path && mediaUrl && (message.attachment_type?.startsWith('image/')
            ? <a href={mediaUrl} target="_blank" rel="noreferrer"><img src={mediaUrl} alt="Chat attachment"/></a>
            : <audio controls preload="metadata" src={mediaUrl}/>)}
          {message.attachment_path && !mediaUrl && <span className="mq-chat-file"><Music2 size={15}/> Loading attachment…</span>}
          <time>{new Date(message.created_at).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })} {mine && (message.read_at ? <CheckCheck size={13}/> : <CheckCheck size={13} opacity={0.5}/>)}</time>
        </article>;
      })}
      {!messages.length && <p className="mq-chat-empty">Your first message is waiting here. Send a little love. 💗</p>}
      <div ref={bottom}/>
    </div>
    <form className="mq-chat-compose" onSubmit={submit}>
      <label className="mq-chat-attach" title="Attach photo or audio"><Paperclip size={18}/><input type="file" accept="image/*,audio/*" onChange={e => setFile(e.target.files?.[0] || null)}/></label>
      <input value={body} onChange={e => setBody(e.target.value)} placeholder="Write something sweet…" aria-label="Message"/>
      <button type="submit" disabled={busy || (!body.trim() && !file)} aria-label="Send message"><Send size={18}/></button>
      {file && <span className="mq-chat-selected">{file.type.startsWith('image/') ? <ImageIcon size={13}/> : <Music2 size={13}/>} {file.name}<button type="button" onClick={() => setFile(null)}>×</button></span>}
    </form>
    <small className="mq-chat-note">Private to the two conversation members through Supabase access policies. Not end-to-end encrypted.</small>
  </section>;
}
