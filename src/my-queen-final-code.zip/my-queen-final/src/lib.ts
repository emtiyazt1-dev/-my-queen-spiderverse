import { createClient, type SupabaseClient } from '@supabase/supabase-js';

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const key = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;
export const supabase: SupabaseClient | null = url && key ? createClient(url, key, {
  auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true },
}) : null;

const DB = 'mq-spiderverse-v1';
export function loadData<T>(key: string, fallback: T): T {
  try { const raw = localStorage.getItem(`${DB}:${key}`); return raw ? JSON.parse(raw) as T : fallback; }
  catch { return fallback; }
}
export function saveData<T>(key: string, value: T): void {
  try { localStorage.setItem(`${DB}:${key}`, JSON.stringify(value)); } catch (e) { console.warn('Local save failed', e); }
}
export async function signIn(email: string, password: string) {
  if (!supabase) throw new Error('Supabase is not configured. Add the VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY environment variables.');
  const { data, error } = await supabase.auth.signInWithPassword({ email: email.trim().toLowerCase(), password });
  if (error) throw error; return data;
}
export async function requestPasswordReset(email: string) {
  if (!supabase) throw new Error('Supabase is not configured.');
  const redirectTo = `${window.location.origin}/`;
  const { error } = await supabase.auth.resetPasswordForEmail(email.trim().toLowerCase(), { redirectTo });
  if (error) throw error;
}
export async function loadCloudData(): Promise<Record<string, any>> {
  if (!supabase) throw new Error('Supabase is not configured.');
  const { data, error } = await supabase.from('app_state').select('state_key,state_value');
  if (error) throw error;
  return Object.fromEntries((data || []).map((row: any) => [row.state_key, row.state_value]));
}
export async function saveCloudData(key: string, value: unknown): Promise<void> {
  if (!supabase) throw new Error('Supabase is not configured.');
  const { data: { user }, error: userError } = await supabase.auth.getUser();
  if (userError || !user) throw userError || new Error('Your session has expired. Please sign in again.');
  const { error } = await supabase.from('app_state').upsert({ user_id: user.id, state_key: key, state_value: value, updated_at: new Date().toISOString() }, { onConflict: 'user_id,state_key' });
  if (error) throw error; saveData(key, value);
}
export async function storeImage(file: File): Promise<string> {
  if (!supabase) throw new Error('Cloud storage is not configured.');
  const { data: { user }, error: userError } = await supabase.auth.getUser();
  if (userError || !user) throw userError || new Error('Please sign in again.');
  const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, '-').slice(-80) || 'photo.jpg';
  const path = `${user.id}/${crypto.randomUUID()}-${safeName}`;
  const { error } = await supabase.storage.from('queen-private').upload(path, file, { cacheControl: '3600', upsert: false, contentType: file.type });
  if (error) throw error; return path;
}
export async function getPrivateImageUrl(path: string): Promise<string> {
  if (!supabase) return '';
  const { data, error } = await supabase.storage.from('queen-private').createSignedUrl(path, 3600);
  if (error) throw error; return data.signedUrl;
}
export async function deletePrivateImage(path: string): Promise<void> {
  if (!supabase) return; const { error } = await supabase.storage.from('queen-private').remove([path]); if (error) throw error;
}
export type ChatMessage = { id: string; conversation_id: string; sender_id: string; body: string | null; attachment_path: string | null; attachment_type: string | null; created_at: string; read_at: string | null };
export async function getChatMessages(conversationId: string): Promise<ChatMessage[]> {
  if (!supabase) throw new Error('Supabase is not configured.');
  const { data, error } = await supabase.from('queen_messages').select('*').eq('conversation_id', conversationId).order('created_at', { ascending: true }).limit(300);
  if (error) throw error; return (data || []) as ChatMessage[];
}
export async function sendChatMessage(conversationId: string, body: string, file?: File): Promise<ChatMessage> {
  if (!supabase) throw new Error('Supabase is not configured.');
  const { data: { user }, error: userError } = await supabase.auth.getUser();
  if (userError || !user) throw userError || new Error('Please sign in again.');
  let attachmentPath: string | null = null; let attachmentType: string | null = null;
  if (file) {
    if (file.size > 15 * 1024 * 1024) throw new Error('Attachment must be 15 MB or smaller.');
    if (!file.type.startsWith('image/') && !file.type.startsWith('audio/')) throw new Error('Only photos and audio files are supported.');
    const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, '-').slice(-80) || 'attachment';
    attachmentPath = `chat/${conversationId}/${user.id}/${crypto.randomUUID()}-${safeName}`;
    const { error } = await supabase.storage.from('queen-private').upload(attachmentPath, file, { upsert: false, contentType: file.type });
    if (error) throw error; attachmentType = file.type;
  }
  const { data, error } = await supabase.from('queen_messages').insert({ conversation_id: conversationId, sender_id: user.id, body: body.trim() || null, attachment_path: attachmentPath, attachment_type: attachmentType }).select('*').single();
  if (error) throw error; return data as ChatMessage;
}
export async function getChatAttachmentUrl(path: string): Promise<string> {
  if (!supabase) throw new Error('Supabase is not configured.');
  const { data, error } = await supabase.storage.from('queen-private').createSignedUrl(path, 900);
  if (error) throw error; return data.signedUrl;
}
export async function markChatRead(messageIds: string[]): Promise<void> {
  if (!supabase || !messageIds.length) return;
  const { data: { user } } = await supabase.auth.getUser(); if (!user) return;
  const { error } = await supabase.from('queen_messages').update({ read_at: new Date().toISOString() }).in('id', messageIds).neq('sender_id', user.id);
  if (error) throw error;
}
