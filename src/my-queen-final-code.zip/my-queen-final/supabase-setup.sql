-- MY QUEEN / Spider-Verse: run in Supabase Dashboard > SQL Editor as project owner.
-- Create both accounts first in Authentication > Users.

create table if not exists public.app_state (
  user_id uuid not null references auth.users(id) on delete cascade,
  state_key text not null,
  state_value jsonb not null,
  updated_at timestamptz not null default now(),
  primary key (user_id, state_key)
);
alter table public.app_state enable row level security;
drop policy if exists "Users manage their own app state" on public.app_state;
create policy "Users manage their own app state" on public.app_state for all to authenticated
  using (auth.uid() = user_id) with check (auth.uid() = user_id);
grant select, insert, update, delete on public.app_state to authenticated;

create table if not exists public.queen_conversations (
  id uuid primary key default gen_random_uuid(), title text not null default 'Our private chat', created_at timestamptz not null default now()
);
create table if not exists public.queen_conversation_members (
  conversation_id uuid not null references public.queen_conversations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  primary key (conversation_id, user_id)
);
create table if not exists public.queen_messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.queen_conversations(id) on delete cascade,
  sender_id uuid not null references auth.users(id) on delete cascade,
  body text,
  attachment_path text,
  attachment_type text,
  created_at timestamptz not null default now(),
  read_at timestamptz,
  constraint queen_messages_content_check check (coalesce(length(body), 0) > 0 or attachment_path is not null)
);
create index if not exists queen_messages_conversation_created_idx on public.queen_messages(conversation_id, created_at);

alter table public.queen_conversations enable row level security;
alter table public.queen_conversation_members enable row level security;
alter table public.queen_messages enable row level security;
drop policy if exists "Members can view conversations" on public.queen_conversations;
create policy "Members can view conversations" on public.queen_conversations for select to authenticated
using (exists (select 1 from public.queen_conversation_members m where m.conversation_id = id and m.user_id = auth.uid()));
drop policy if exists "Members can view membership" on public.queen_conversation_members;
create policy "Members can view membership" on public.queen_conversation_members for select to authenticated using (user_id = auth.uid());
drop policy if exists "Members can read messages" on public.queen_messages;
create policy "Members can read messages" on public.queen_messages for select to authenticated
using (exists (select 1 from public.queen_conversation_members m where m.conversation_id = queen_messages.conversation_id and m.user_id = auth.uid()));
drop policy if exists "Members can send messages as themselves" on public.queen_messages;
create policy "Members can send messages as themselves" on public.queen_messages for insert to authenticated
with check (sender_id = auth.uid() and exists (select 1 from public.queen_conversation_members m where m.conversation_id = queen_messages.conversation_id and m.user_id = auth.uid()));
drop policy if exists "Recipients can mark messages read" on public.queen_messages;
create policy "Recipients can mark messages read" on public.queen_messages for update to authenticated
using (sender_id <> auth.uid() and exists (select 1 from public.queen_conversation_members m where m.conversation_id = queen_messages.conversation_id and m.user_id = auth.uid()))
with check (sender_id <> auth.uid());
grant select, insert on public.queen_messages to authenticated;
grant update (read_at) on public.queen_messages to authenticated;
grant select on public.queen_conversations, public.queen_conversation_members to authenticated;

-- Private storage bucket. Gallery paths are <user-uuid>/<file>; chat paths are chat/<conversation-uuid>/<sender-uuid>/<file>.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('queen-private', 'queen-private', false, 15728640,
  array['image/jpeg','image/png','image/webp','image/gif','audio/mpeg','audio/mp4','audio/wav','audio/ogg','audio/webm'])
on conflict (id) do update set public = false, file_size_limit = 15728640;

drop policy if exists "Users access own private media" on storage.objects;
create policy "Users access own private media" on storage.objects for all to authenticated
using (bucket_id = 'queen-private' and (storage.foldername(name))[1] = auth.uid()::text)
with check (bucket_id = 'queen-private' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "Chat members can read chat attachments" on storage.objects;
create policy "Chat members can read chat attachments" on storage.objects for select to authenticated
using (bucket_id = 'queen-private' and (storage.foldername(name))[1] = 'chat' and exists (
  select 1 from public.queen_conversation_members m
  where m.conversation_id::text = (storage.foldername(name))[2] and m.user_id = auth.uid()
));
drop policy if exists "Chat members can upload their own chat attachments" on storage.objects;
create policy "Chat members can upload their own chat attachments" on storage.objects for insert to authenticated
with check (bucket_id = 'queen-private' and (storage.foldername(name))[1] = 'chat'
  and (storage.foldername(name))[3] = auth.uid()::text and exists (
    select 1 from public.queen_conversation_members m
    where m.conversation_id::text = (storage.foldername(name))[2] and m.user_id = auth.uid()
));

-- Run this section AFTER both Auth users exist. Replace the UUID placeholders with real Auth user IDs.
-- insert into public.queen_conversations (id, title) values ('11111111-1111-1111-1111-111111111111', 'Our private chat');
-- insert into public.queen_conversation_members (conversation_id, user_id) values
-- ('11111111-1111-1111-1111-111111111111', 'YOUR_AUTH_USER_UUID'),
-- ('11111111-1111-1111-1111-111111111111', 'QUEEN_AUTH_USER_UUID');
-- Then set VITE_CHAT_CONVERSATION_ID to the conversation UUID in Vercel Environment Variables.

do $$ begin
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'queen_messages') then
    alter publication supabase_realtime add table public.queen_messages;
  end if;
end $$;
